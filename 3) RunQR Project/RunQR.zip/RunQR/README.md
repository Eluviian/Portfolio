# RunQR

Note: Project Part 3
So far most of the app functionality works for adding and viewing QRCodes except due to database errors we are unable to load the player data once app is destroyed.
If app is paused the behavior is fine. 
We will work on fixing the functionality after onDestroy(), for now the app needs to be uninstalled and reinstalled after onDestroy() to work.
