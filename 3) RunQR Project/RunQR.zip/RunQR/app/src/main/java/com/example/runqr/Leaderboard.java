package com.example.runqr;

public class Leaderboard {
    /*mode will switch between different boards when buttons are pressed*/
    private int mode;

    /*combine this class with LeaderboardActivity?*/

    /*need to make custom list containing player name and score for each mode, values will be stored in firebase*/
    //most valuable qr code list
    //most qr codes scanned list
    //highest point sum list

}
