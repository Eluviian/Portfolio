package com.example.runqr;

public class Photo {
    private byte image;

    public byte getImage() {
        return image;
    }

    public void setImage(byte image) {
        this.image = image;
    }
}
